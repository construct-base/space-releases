import { vi } from 'vitest'

export const invoke = vi.fn()
