<script setup lang="ts">
// Code Editor space — placeholder
</script>

<template>
  <div class="flex items-center justify-center h-full">
    <div class="text-center">
      <h1 class="text-3xl font-bold text-app mb-2">CODE EDITOR</h1>
      <p class="text-app-muted">Space migration in progress</p>
    </div>
  </div>
</template>
