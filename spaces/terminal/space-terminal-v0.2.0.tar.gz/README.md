# terminal Space

Source of truth for the `terminal` space used by Construct apps.
