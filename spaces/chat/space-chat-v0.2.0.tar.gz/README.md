# chat Space

Source of truth for the `chat` space used by Construct apps.
