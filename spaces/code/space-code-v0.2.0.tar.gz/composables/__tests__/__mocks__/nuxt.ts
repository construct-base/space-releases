// Re-export Vue reactivity as if coming from #app
export { ref, computed, reactive, watch, nextTick, toRaw, toRef, toRefs, shallowRef, triggerRef, watchEffect, onMounted, onUnmounted } from 'vue'
export type { Ref, ComputedRef } from 'vue'
