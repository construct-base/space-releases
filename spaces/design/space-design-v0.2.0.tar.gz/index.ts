/**
 * Design Space — PixiJS 8-powered design canvas
 */
export { default as config } from './space.config'
export { useDesignEngine } from './composables/useDesignEngine'
export { useUIState } from './composables/useUIState'
export { useLocalDesigns, type UIDesign } from './composables/useLocalDesigns'
export type { UITool, TextPreset } from './types'
