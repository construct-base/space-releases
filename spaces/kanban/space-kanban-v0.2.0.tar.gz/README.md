# kanban Space

Source of truth for the `kanban` space used by Construct apps.
