# notes Space

Source of truth for the `notes` space used by Construct apps.
