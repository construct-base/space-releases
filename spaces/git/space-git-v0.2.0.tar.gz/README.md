# git Space

Source of truth for the `git` space used by Construct apps.
