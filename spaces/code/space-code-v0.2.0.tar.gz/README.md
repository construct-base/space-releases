# code Space

Source of truth for the `code` space used by Construct apps.
