# design Space

Source of truth for the `design` space used by Construct apps.
