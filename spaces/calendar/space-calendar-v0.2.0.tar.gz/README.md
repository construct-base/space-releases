# calendar Space

Source of truth for the `calendar` space used by Construct apps.
